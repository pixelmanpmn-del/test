export enum CellStatus {
  HIDDEN = 'HIDDEN',
  REVEALED = 'REVEALED',
  FLAGGED = 'FLAGGED',
}

export interface CellData {
  id: string;
  row: number;
  col: number;
  isMine: boolean;
  neighborMines: number;
  status: CellStatus;
}

export enum GameStatus {
  READY = 'READY',
  PLAYING = 'PLAYING',
  WON = 'WON',
  LOST = 'LOST',
}

export interface Difficulty {
  name: string;
  rows: number;
  cols: number;
  mines: number;
}
