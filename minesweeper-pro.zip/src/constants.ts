import { Difficulty } from './types';

export const DIFFICULTIES: Difficulty[] = [
  { name: 'Easy', rows: 9, cols: 9, mines: 10 },
  { name: 'Medium', rows: 16, cols: 16, mines: 40 },
  { name: 'Hard', rows: 16, cols: 30, mines: 99 },
];

export const COLORS = {
  1: 'text-blue-600',
  2: 'text-green-600',
  3: 'text-red-600',
  4: 'text-purple-600',
  5: 'text-orange-600',
  6: 'text-cyan-600',
  7: 'text-brown-600',
  8: 'text-gray-600',
};
