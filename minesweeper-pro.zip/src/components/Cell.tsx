import React from 'react';
import { motion } from 'motion/react';
import { Flag, Bomb } from 'lucide-react';
import { CellData, CellStatus } from '../types';
import { COLORS } from '../constants';

interface CellProps {
  cell: CellData;
  onClick: () => void;
  onContextMenu: (e: React.MouseEvent) => void;
  gameOver: boolean;
}

export const Cell: React.FC<CellProps> = ({ cell, onClick, onContextMenu, gameOver }) => {
  const isRevealed = cell.status === CellStatus.REVEALED;
  const isFlagged = cell.status === CellStatus.FLAGGED;

  return (
    <motion.div
      whileHover={!isRevealed && !gameOver ? { scale: 0.95, backgroundColor: '#ffe4e1' } : {}}
      whileTap={!isRevealed && !gameOver ? { scale: 0.9 } : {}}
      onClick={onClick}
      onContextMenu={onContextMenu}
      className={`
        w-8 h-8 sm:w-10 sm:h-10 flex items-center justify-center text-lg font-bold cursor-pointer
        border border-red-200 transition-all duration-200 rounded-md
        ${isRevealed 
          ? 'bg-white shadow-inner' 
          : 'bg-[#d40000] hover:bg-[#b30000] shadow-md'}
        ${cell.isMine && isRevealed ? 'bg-yellow-100 border-yellow-500' : ''}
      `}
      id={`cell-${cell.row}-${cell.col}`}
    >
      {isRevealed ? (
        cell.isMine ? (
          <span className="text-2xl">🧨</span>
        ) : (
          cell.neighborMines > 0 && (
            <span className={`${COLORS[cell.neighborMines as keyof typeof COLORS]} font-black`}>
              {cell.neighborMines}
            </span>
          )
        )
      ) : isFlagged ? (
        <span className="text-xl animate-bounce">🧧</span>
      ) : null}
    </motion.div>
  );
};
