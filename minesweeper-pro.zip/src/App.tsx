import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Timer, Flag, RefreshCw, Trophy, Skull, Settings2, Bomb } from 'lucide-react';
import { CellStatus, CellData, GameStatus, Difficulty } from './types';
import { DIFFICULTIES } from './constants';
import { Cell } from './components/Cell';

export default function App() {
  const [difficulty, setDifficulty] = useState<Difficulty>(DIFFICULTIES[0]);
  const [grid, setGrid] = useState<CellData[][]>([]);
  const [gameStatus, setGameStatus] = useState<GameStatus>(GameStatus.READY);
  const [mineCount, setMineCount] = useState(difficulty.mines);
  const [time, setTime] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const initGrid = useCallback((diff: Difficulty) => {
    const newGrid: CellData[][] = [];
    for (let r = 0; r < diff.rows; r++) {
      const row: CellData[] = [];
      for (let c = 0; c < diff.cols; c++) {
        row.push({
          id: `${r}-${c}`,
          row: r,
          col: c,
          isMine: false,
          neighborMines: 0,
          status: CellStatus.HIDDEN,
        });
      }
      newGrid.push(row);
    }
    return newGrid;
  }, []);

  const startGame = useCallback((diff: Difficulty) => {
    setGrid(initGrid(diff));
    setGameStatus(GameStatus.READY);
    setMineCount(diff.mines);
    setTime(0);
    if (timerRef.current) clearInterval(timerRef.current);
  }, [initGrid]);

  useEffect(() => {
    startGame(difficulty);
  }, [difficulty, startGame]);

  useEffect(() => {
    if (gameStatus === GameStatus.PLAYING) {
      timerRef.current = setInterval(() => {
        setTime((t) => t + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameStatus]);

  const placeMines = (currentGrid: CellData[][], firstRow: number, firstCol: number) => {
    const newGrid = [...currentGrid.map(row => [...row])];
    let minesPlaced = 0;
    while (minesPlaced < difficulty.mines) {
      const r = Math.floor(Math.random() * difficulty.rows);
      const c = Math.floor(Math.random() * difficulty.cols);
      
      // Don't place mine on first click or already mined cell
      if (!newGrid[r][c].isMine && (Math.abs(r - firstRow) > 1 || Math.abs(c - firstCol) > 1)) {
        newGrid[r][c].isMine = true;
        minesPlaced++;
      }
    }

    // Calculate neighbors
    for (let r = 0; r < difficulty.rows; r++) {
      for (let c = 0; c < difficulty.cols; c++) {
        if (!newGrid[r][c].isMine) {
          let count = 0;
          for (let dr = -1; dr <= 1; dr++) {
            for (let dc = -1; dc <= 1; dc++) {
              const nr = r + dr;
              const nc = c + dc;
              if (nr >= 0 && nr < difficulty.rows && nc >= 0 && nc < difficulty.cols && newGrid[nr][nc].isMine) {
                count++;
              }
            }
          }
          newGrid[r][c].neighborMines = count;
        }
      }
    }
    return newGrid;
  };

  const revealCell = (r: number, c: number) => {
    if (gameStatus === GameStatus.WON || gameStatus === GameStatus.LOST) return;
    if (grid[r][c].status !== CellStatus.HIDDEN) return;

    let newGrid = [...grid.map(row => [...row])];
    
    if (gameStatus === GameStatus.READY) {
      newGrid = placeMines(newGrid, r, c);
      setGameStatus(GameStatus.PLAYING);
    }

    if (newGrid[r][c].isMine) {
      // Game Over
      newGrid[r][c].status = CellStatus.REVEALED;
      // Reveal all mines
      newGrid.forEach(row => row.forEach(cell => {
        if (cell.isMine) cell.status = CellStatus.REVEALED;
      }));
      setGrid(newGrid);
      setGameStatus(GameStatus.LOST);
      return;
    }

    const floodFill = (grid: CellData[][], r: number, c: number) => {
      if (r < 0 || r >= difficulty.rows || c < 0 || c >= difficulty.cols) return;
      if (grid[r][c].status !== CellStatus.HIDDEN || grid[r][c].isMine) return;

      grid[r][c].status = CellStatus.REVEALED;

      if (grid[r][c].neighborMines === 0) {
        for (let dr = -1; dr <= 1; dr++) {
          for (let dc = -1; dc <= 1; dc++) {
            floodFill(grid, r + dr, c + dc);
          }
        }
      }
    };

    floodFill(newGrid, r, c);
    setGrid(newGrid);
    checkWin(newGrid);
  };

  const toggleFlag = (e: React.MouseEvent, r: number, c: number) => {
    e.preventDefault();
    if (gameStatus === GameStatus.WON || gameStatus === GameStatus.LOST) return;
    if (grid[r][c].status === CellStatus.REVEALED) return;

    const newGrid = [...grid.map(row => [...row])];
    const currentStatus = newGrid[r][c].status;

    if (currentStatus === CellStatus.HIDDEN) {
      newGrid[r][c].status = CellStatus.FLAGGED;
      setMineCount(prev => prev - 1);
    } else if (currentStatus === CellStatus.FLAGGED) {
      newGrid[r][c].status = CellStatus.HIDDEN;
      setMineCount(prev => prev + 1);
    }

    setGrid(newGrid);
  };

  const checkWin = (currentGrid: CellData[][]) => {
    const allNonMinesRevealed = currentGrid.every(row => 
      row.every(cell => cell.isMine || cell.status === CellStatus.REVEALED)
    );
    if (allNonMinesRevealed) {
      setGameStatus(GameStatus.WON);
    }
  };

  return (
    <div className="min-h-screen bg-[#fff8f0] text-[#4a0000] font-sans p-4 md:p-8 flex flex-col items-center selection:bg-red-500/20">
      <motion.header 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-4xl mb-8 flex flex-col md:flex-row justify-between items-center gap-6"
      >
        <div className="flex items-center gap-4">
          <div className="bg-[#d40000] text-[#ffd700] p-4 rounded-full shadow-[0_0_20px_rgba(212,0,0,0.3)] border-4 border-[#ffd700]">
            <span className="text-4xl">🐎</span>
          </div>
          <div>
            <h1 className="text-4xl font-black tracking-tight text-[#d40000] festive-text-shadow">2026 馬到成功</h1>
            <p className="text-sm font-bold text-[#b38b00] uppercase tracking-[0.2em] mt-1">Year of the Horse // 新春特別版</p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-white p-2 rounded-2xl border-2 border-[#ffd700] shadow-lg">
          {DIFFICULTIES.map((diff) => (
            <button
              key={diff.name}
              onClick={() => setDifficulty(diff)}
              className={`px-6 py-2 rounded-xl text-sm font-black transition-all ${
                difficulty.name === diff.name 
                  ? 'bg-[#d40000] text-[#ffd700] shadow-md' 
                  : 'text-[#4a0000] hover:bg-red-50'
              }`}
            >
              {diff.name}
            </button>
          ))}
        </div>
      </motion.header>

      <main className="w-full flex flex-col items-center gap-6">
        {/* Stats Bar */}
        <div className="w-full max-w-fit flex justify-between items-center gap-12 bg-white px-12 py-6 rounded-[2rem] border-4 border-[#ffd700] shadow-xl relative">
          <div className="flex flex-col items-center gap-1">
            <span className="text-xs uppercase tracking-widest text-[#b38b00] font-black">剩餘紅包</span>
            <div className="flex items-center gap-3">
              <span className="text-2xl">🧧</span>
              <span className="font-mono text-4xl font-black tabular-nums text-[#d40000]">
                {String(mineCount).padStart(3, '0')}
              </span>
            </div>
          </div>
          
          <button 
            onClick={() => startGame(difficulty)}
            className="p-5 bg-[#d40000] hover:bg-[#b30000] rounded-full transition-all group hover:scale-110 active:scale-95 shadow-lg border-2 border-[#ffd700]"
          >
            <RefreshCw className={`w-8 h-8 text-[#ffd700] group-active:rotate-180 transition-transform duration-500 ${gameStatus === GameStatus.PLAYING ? 'animate-spin-slow' : ''}`} />
          </button>

          <div className="flex flex-col items-center gap-1">
            <span className="text-xs uppercase tracking-widest text-[#b38b00] font-black">新春計時</span>
            <div className="flex items-center gap-3">
              <span className="text-2xl">⏳</span>
              <span className="font-mono text-4xl font-black tabular-nums text-[#d40000]">
                {String(time).padStart(3, '0')}
              </span>
            </div>
          </div>
        </div>

        {/* Game Board */}
        <div className="relative p-6 bg-[#d40000] rounded-3xl shadow-2xl border-8 border-[#ffd700] overflow-auto max-w-full">
          {/* Decorative Corners */}
          <div className="absolute top-2 left-2 text-2xl opacity-50">🏮</div>
          <div className="absolute top-2 right-2 text-2xl opacity-50">🏮</div>
          <div className="absolute bottom-2 left-2 text-2xl opacity-50">🏮</div>
          <div className="absolute bottom-2 right-2 text-2xl opacity-50">🏮</div>

          <div 
            className="grid gap-1.5"
            style={{ 
              gridTemplateColumns: `repeat(${difficulty.cols}, minmax(0, 1fr))`,
              width: 'max-content'
            }}
          >
            {grid.map((row, r) => 
              row.map((cell, c) => (
                <Cell 
                  key={cell.id}
                  cell={cell}
                  onClick={() => revealCell(r, c)}
                  onContextMenu={(e) => toggleFlag(e, r, c)}
                  gameOver={gameStatus === GameStatus.LOST || gameStatus === GameStatus.WON}
                />
              ))
            )}
          </div>

          <AnimatePresence>
            {(gameStatus === GameStatus.WON || gameStatus === GameStatus.LOST) && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 z-10 flex items-center justify-center bg-black/60 backdrop-blur-md rounded-xl"
              >
                <div className="bg-white p-12 rounded-[3rem] shadow-[0_0_50px_rgba(212,0,0,0.4)] text-center flex flex-col items-center gap-6 border-8 border-[#ffd700] relative max-w-sm">
                  {gameStatus === GameStatus.WON ? (
                    <>
                      <div className="text-7xl mb-2 animate-bounce">🐎</div>
                      <div>
                        <h2 className="text-5xl font-black text-[#d40000] tracking-tighter">馬到成功!</h2>
                        <p className="text-[#b38b00] font-bold text-lg mt-4">恭喜發財，萬事如意！</p>
                        <p className="text-zinc-500 text-sm mt-2">用時：{time} 秒</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="text-7xl mb-2">💥</div>
                      <div>
                        <h2 className="text-5xl font-black text-[#d40000] tracking-tighter">馬失前蹄</h2>
                        <p className="text-[#b38b00] font-bold text-lg mt-4">歲歲平安，再接再厲！</p>
                      </div>
                    </>
                  )}
                  <button 
                    onClick={() => startGame(difficulty)}
                    className="mt-4 px-12 py-4 bg-[#d40000] text-[#ffd700] font-black uppercase tracking-widest rounded-full hover:bg-[#b30000] transition-all shadow-xl hover:scale-105 active:scale-95 border-2 border-[#ffd700]"
                  >
                    重新開運
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Instructions */}
        <div className="mt-8 text-center max-w-md bg-white/50 p-6 rounded-2xl border-2 border-[#ffd700]/30">
          <div className="flex items-center justify-center gap-2 mb-4">
            <span className="text-xl">📜</span>
            <span className="text-sm font-black uppercase tracking-[0.2em] text-[#d40000]">新春玩法指南</span>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col items-center">
              <span className="text-xs text-[#b38b00] font-bold mb-1">左鍵點擊</span>
              <p className="text-sm font-black text-[#4a0000]">翻開春聯</p>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-xs text-[#b38b00] font-bold mb-1">右鍵點擊</span>
              <p className="text-sm font-black text-[#4a0000]">標記紅包</p>
            </div>
          </div>
        </div>
      </main>

      <footer className="mt-auto pt-12 pb-4 opacity-50 text-xs font-bold text-[#d40000] flex flex-col items-center gap-2">
        <div className="flex items-center gap-4">
          <span>🧧 恭賀新禧</span>
          <span>🐎 龍馬精神</span>
          <span>🧧 大吉大利</span>
        </div>
        <p className="text-[10px] opacity-50 tracking-[0.2em]">© 2026 YEAR OF THE HORSE EDITION</p>
      </footer>
    </div>
  );
}
